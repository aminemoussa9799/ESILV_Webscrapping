Bonjour Madame,
D'abord merci d'avoir partagé vos connaissances avec nous, je n'ai pas toujours été 
présent en classe, mais j'ai toujours suivi le cours qui me semble aussi bien important
qu'interessant !

Pour ce projet, vous pouvez soit:
- ouvrir seulement le fichier "project.py" qui:
	1. Scrappe les données des sites
	2. Fait du data cleaning
	3. Fait de la Data Analyse/Viz
- ouvrir le dossier "WebScrapping_GUI" dans un IDE qui contient:
	1. "app.py" qui contient tous les élements de "project.py" + une app Flask
	    (à executer pour avoir l'IHM)
	2. "templates" et "static" contiennent les codes HTML et CSS associés à l'IHM