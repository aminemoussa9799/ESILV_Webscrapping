################################################ LIBRARIES ################################################
from flask import Flask, render_template
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import datetime as dt


###################################### DATA VIZUALISATION ########################################
# Data Viz 1: Create a stacked bar chart visualization using Plotly$
def finals_played_bar(african_clubs_cl_dataset):
    fig = px.bar(african_clubs_cl_dataset, x="Club", y=["Number Victoires", "Number Finales perdues"], 
                                        title="Number of Finals played (Won and Lost) in African Champions League", 
                                        labels={"Number Victoires": "Victories", "Number Finales perdues": "Final Losses"},
                                        color_discrete_sequence=["#006400", "#8B0000"])
    fig.update_layout(title_font_size=15, title_x=0.1, xaxis_title_font_size=20, yaxis_title_font_size=20)
    return fig
    #fig.show()

# Data Viz 2: # Create a time series data visualization using Plotly
def finals_won_time_series(african_clubs_cl_dataset, top=5):
    top_5_clubs = african_clubs_cl_dataset.head(top)
    top_5_clubs["Dates Victoires"] = top_5_clubs["Dates Victoires"].apply(lambda x: x[1:-1].split(" "))

    # Use the line plot function from the Plotly express library to generate the plot
    all_dates = range(1960, dt.date.today().year+1)

    # Create a list of traces for the line plots
    traces = []
    for _, club in top_5_clubs.iterrows():
        # Create a list of cumulative victories for each date
        cumul_victs = []
        for date in all_dates:
            if str(date) in club['Dates Victoires']:
                cumul_victs.append(1 if len(cumul_victs) == 0 else cumul_victs[-1]+1)
            else:
                cumul_victs.append(0 if len(cumul_victs) == 0 else cumul_victs[-1])  # Add a None value for dates with no victory
        color = px.colors.qualitative.Plotly[_]
        traces.append(go.Scatter(x=list(all_dates), y=cumul_victs, name=club['Club'], line=dict(color=color)))
        traces.append(go.Scatter(x=club["Dates Victoires"], y=list(range(1, club["Number Victoires"]+1)), name=club['Club'], mode="markers", showlegend=False, marker=dict(color=color, size=10)))

    # Create the figure object with the traces
    layout = go.Layout(xaxis=dict(dtick=5))
    fig = go.Figure(data=traces, layout=layout)
    fig.update_layout(title="Top " + str(top) + " Clubs - Number of Trophies Over Time", title_font_size=15, title_x=0.5, xaxis_title_font_size=20, yaxis_title_font_size=20)
    return fig
    #fig.show()

# Data Vuz 3: Group the data by country and sum the number of victories for each country
def finals_country_donut(african_clubs_cl_dataset, top=5):
    grouped_df = african_clubs_cl_dataset.groupby(by="Country")["Number Victoires"].sum().reset_index()
    grouped_df = grouped_df.sort_values(by="Number Victoires", ascending=False)  # Sort the data by the number of victories desc
    top_5_countries = grouped_df.head(top)  # Select the top 5 countries

    # Create a donut chart visualization using Plotly
    fig = px.pie(top_5_countries, values="Number Victoires", names="Country", title="Top " + str(top) + " Countries in Number of Victories", hole=0.4)
    fig.update_traces(textfont=dict(size=20, family='Arial, bold'))
    fig.update_layout(title_font_size=15, title_x=0.15, xaxis_title_font_size=20, yaxis_title_font_size=20)
    return fig
    #fig.show()

###################################### MAIN APP ########################################
app = Flask(__name__)

@app.route('/')
def index():
    # Import Scraped Data (after Cleaning)
    african_clubs_cl_dataset = pd.read_csv("african_clubs_cl_dataset.csv", sep=";").set_index("Rang", drop=True)
    print(african_clubs_cl_dataset.to_string())

    # Graphs as HTML
    fig1_div = finals_played_bar(african_clubs_cl_dataset=african_clubs_cl_dataset).to_html(full_html=False)
    fig2_div = finals_won_time_series(african_clubs_cl_dataset=african_clubs_cl_dataset, top=5).to_html(full_html=False)
    fig3_div = finals_country_donut(african_clubs_cl_dataset=african_clubs_cl_dataset, top=10).to_html(full_html=False)
    # Render the HTML template with the Plotly graph
    return render_template('index.html', graphs=[fig1_div, fig2_div, fig3_div])

# Main Flask
if __name__ == '__main__':
    app.run(debug=True)
