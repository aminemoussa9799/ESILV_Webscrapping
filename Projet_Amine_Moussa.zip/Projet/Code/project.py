################################################ LIBRARIES ################################################
import requests
from bs4 import BeautifulSoup
import pandas as pd
from fuzzywuzzy import fuzz
import plotly.express as px
import plotly.graph_objects as go
import datetime as dt

###################################### SCRAPPING - CLUBS/COUNTRUES ########################################
# Fetch the HTML content of the page
url = "https://en.wikipedia.org/wiki/List_of_top-division_football_clubs_in_CAF_countries"
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser') # Parse the HTML content using BeautifulSoup

# Extract the country names and Fix countries with 2 tables instead of 1 
country_names = [h2.find('span', class_='mw-headline').text for h2 in soup.find_all('h2') if h2.find('span', class_='mw-headline')]
country_names = sorted(country_names[:-2] + ["Cape Verde", "Equatorial Guinea", "Madagascar"])

# Fix the Order ("é" and "w")
e, w = country_names.index("Réunion"), country_names.index("Rwanda")
country_names[e], country_names[w] = country_names[w], country_names[e]

# Fix the Order ("a" and "à")
country_names.remove("São Tomé and Príncipe"); country_names.insert(country_names.index("Rwanda")+1, "São Tomé and Príncipe")
#print(country_names)

# Iterate over the tables and extract the ones that contain "Club" and "City" headers
clubs, cnt = [], 0
for table in soup.find_all('table'):
    if any(th.text.strip() in ["Club", "City", "Team name"] for th in table.find_all('th')):
        df = pd.read_html(str(table))[0]
        df["Country"] = country_names[cnt]; cnt += 1
        clubs.append(df)


# Merge all the dataframes into a single dataframe (Fuse some similar Cols)
african_clubs_countries = pd.concat(clubs, ignore_index=True)
african_clubs_countries["Club"] = african_clubs_countries["Club"].fillna(african_clubs_countries["Team name"])
#print(african_clubs_countries[["Club", "Country"]].to_string())

###################################### SCRAPPING - CLUBS/COUNTRUES ########################################
def extract_dates(df, col_name):
    df["Number " + col_name] = df[col_name].str.extract(r"(\d+)").apply(lambda x: pd.to_numeric(x))
    df["Dates " + col_name] = df[col_name].str.extract(r"\((.*)\)")  # Extract Dates
    df["Dates " + col_name] = df["Dates " + col_name].str.split(", ").apply(lambda x: pd.to_datetime(x)) # Put them in list
    return df

# Send a request to the website and retrieve the HTML content
# Fetch the HTML content of the webpage
url = "https://fr.wikipedia.org/wiki/Ligue_des_champions_de_la_CAF"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

# Find the table with the caption "Palmarès par club"
table = soup.find("caption", text="Palmarès par club\n").find_parent("table")

# Print the content of the table
african_clubs_cl_performance = pd.read_html(str(table))[0].set_index("Rang", drop=True).iloc[:-1, :]

# Extract the numbers and Date from the chosen Columns
african_clubs_cl_performance = extract_dates(african_clubs_cl_performance, "Victoires")
african_clubs_cl_performance = extract_dates(african_clubs_cl_performance, "Finales perdues")

# Print the resulting DataFrame
african_clubs_cl_performance = african_clubs_cl_performance[["Club", "Number Victoires", "Number Finales perdues", "Victoires", "Dates Victoires", "Dates Finales perdues"]]
#print(african_clubs_cl_performance)

###################################### DATA CLEANING/EXPLORATION ########################################
# Join the 2 datasets on club name to get the country on the first dataset and join it to the performances of second one
def get_country(club_name, source, sim_perc=80):
    # Calculate the string similarity between the club name and each club name in african_clubs_countries
    similarity = source['Club'].apply(lambda x: fuzz.token_set_ratio(club_name, x))
    # If there is a match with at least the specified percentage of similarity, return the corresponding country
    return source[similarity>=sim_perc]['Country'].values[0] if any(similarity>=sim_perc) else None
        

# Apply the get_country function to each row of african_clubs_cl_performance
african_clubs_cl_performance["Country"] = african_clubs_cl_performance["Club"].apply(get_country, sim_perc=72.5, source=african_clubs_countries)
african_clubs_cl_dataset = african_clubs_cl_performance.dropna(subset=["Country"])
ordered_columns = [african_clubs_cl_dataset.columns[0], african_clubs_cl_dataset.columns[-1]] + list(african_clubs_cl_dataset.columns[1:-1])
african_clubs_cl_dataset = african_clubs_cl_dataset[ordered_columns]
#print(african_clubs_cl_dataset)
#african_clubs_cl_dataset.to_csv("african_clubs_cl_dataset_.csv", sep=";")

###################################### DATA VIZUALISATION ########################################
# Data Viz 1: Create a stacked bar chart visualization using Plotly$
def finals_played_bar(african_clubs_cl_dataset):
    fig = px.bar(african_clubs_cl_dataset, x="Club", y=["Number Victoires", "Number Finales perdues"], 
                                        title="Number of Finals played (Won and Lost) in African Champions League", 
                                        labels={"Number Victoires": "Victories", "Number Finales perdues": "Final Losses"},
                                        color_discrete_sequence=["#006400", "#8B0000"])
    fig.update_layout(title_font_size=30, title_x=0.1, xaxis_title_font_size=20, yaxis_title_font_size=20)
    return fig
    #fig.show()

# Data Viz 2: # Create a time series data visualization using Plotly
def finals_won_time_series(african_clubs_cl_dataset, top=5):
    top_5_clubs = african_clubs_cl_dataset.head(top)
    top_5_clubs["Dates Victoires"] = top_5_clubs["Dates Victoires"].apply(lambda x: x[1:-1].split(" "))

    # Use the line plot function from the Plotly express library to generate the plot
    all_dates = range(1960, dt.date.today().year+1)

    # Create a list of traces for the line plots
    traces = []
    for _, club in top_5_clubs.iterrows():
        # Create a list of cumulative victories for each date
        cumul_victs = []
        for date in all_dates:
            if str(date) in club['Dates Victoires']:
                cumul_victs.append(1 if len(cumul_victs) == 0 else cumul_victs[-1]+1)
            else:
                cumul_victs.append(0 if len(cumul_victs) == 0 else cumul_victs[-1])  # Add a None value for dates with no victory
        color = px.colors.qualitative.Plotly[_]
        traces.append(go.Scatter(x=list(all_dates), y=cumul_victs, name=club['Club'], line=dict(color=color)))
        traces.append(go.Scatter(x=club["Dates Victoires"], y=list(range(1, club["Number Victoires"]+1)), name=club['Club'], mode="markers", showlegend=False, marker=dict(color=color, size=10)))

    # Create the figure object with the traces
    layout = go.Layout(xaxis=dict(dtick=5))
    fig = go.Figure(data=traces, layout=layout)
    fig.update_layout(title="Top " + str(top) + " Clubs - Number of Trophies Over Time", title_font_size=30, title_x=0.5, xaxis_title_font_size=20, yaxis_title_font_size=20)
    return fig
    #fig.show()

# Data Vuz 3: Group the data by country and sum the number of victories for each country
def finals_country_donut(african_clubs_cl_dataset, top=5):
    grouped_df = african_clubs_cl_dataset.groupby(by="Country")["Number Victoires"].sum().reset_index()
    grouped_df = grouped_df.sort_values(by="Number Victoires", ascending=False)  # Sort the data by the number of victories desc
    top_5_countries = grouped_df.head(top)  # Select the top 5 countries

    # Create a donut chart visualization using Plotly
    fig = px.pie(top_5_countries, values="Number Victoires", names="Country", title="Top " + str(top) + " Countries in Number of Victories", hole=0.4)
    fig.update_traces(textfont=dict(size=20, family='Arial, bold'))
    fig.update_layout(title_font_size=30, title_x=0.15, xaxis_title_font_size=20, yaxis_title_font_size=20)
    return fig
    #fig.show()

###################################### MAIN APP ########################################
african_clubs_cl_dataset = pd.read_csv("african_clubs_cl_dataset.csv", sep=";").set_index("Rang", drop=True)
print(african_clubs_cl_dataset.to_string())

finals_played_bar(african_clubs_cl_dataset=african_clubs_cl_dataset).show()
finals_won_time_series(african_clubs_cl_dataset=african_clubs_cl_dataset, top=5).show()
finals_country_donut(african_clubs_cl_dataset=african_clubs_cl_dataset, top=10).show()

